<h1>ingress passcodes auto use</h1>
<img src="https://raw.githubusercontent.com/yesnosurely/ingress-passcodes-auto-use/master/preview.JPG">

## Установка
<ul>
<li>Установите <a href="https://tampermonkey.net/" target="_blank">tampermonkey</a></li>
<li>Установите <a href="https://raw.githubusercontent.com/yesnosurely/ingress-passcodes-auto-use/master/ingress-passcodes-auto-use.user.js" target="_blank">скрипт</a></li>
</ul>

## Использование
<ul>
<li>Откройте <a href="https://intel.ingress.com/" target="_blank">intel</a></li>
<li>В боковой панеле найдите область с названием "passcodes", или нажмите на кнопку "passcodes" в оригинальном интеле</li>
<li>Вставьте ваш список пасскодов и нажмите Enter</li>
</ul>


## Installation
<ul>
<li>Install <a href="https://tampermonkey.net/" target="_blank">tampermonkey</a></li>
<li>Install <a href="https://raw.githubusercontent.com/yesnosurely/ingress-passcodes-auto-use/master/ingress-passcodes-auto-use.user.js" target="_blank">script</a></li>
</ul>

## Usage
<ul>
<li>Open <a href="https://intel.ingress.com/" target="_blank">intel</a></li>
<li>In the sidebar, find the area called "passcodes", or click on the "passcodes" button in the original intel</li>
<li>Insert your passcodes list and press Enter</li>
</ul>

