// ==UserScript==
// @name          Ingress passcodes auto use
// @author        @yesnosurely
// @namespace     https://github.com/yesnosurely/ingress-passcodes-auto-use/
// @version       2
// @updateURL     https://raw.githubusercontent.com/yesnosurely/ingress-passcodes-auto-use/master/ingress-passcodes-auto-use.meta.js
// @downloadURL   https://raw.githubusercontent.com/yesnosurely/ingress-passcodes-auto-use/master/ingress-passcodes-auto-use.user.js
// @require       http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js
// @match         http://intel.ingress.com/*
// @match         https://intel.ingress.com/*
// ==/UserScript==
